-- Add columns for user-input personality traits (0-100 range)
ALTER TABLE public.resumes
ADD COLUMN "Openness" INTEGER,
ADD COLUMN "Conscientiousness" INTEGER,
ADD COLUMN "Extraversion" INTEGER,
ADD COLUMN "Agreeableness" INTEGER,
ADD COLUMN "Neuroticism" INTEGER;

-- Add columns for AI evaluation results
ALTER TABLE public.resumes
ADD COLUMN "ai_final_score" REAL,       -- For scores like 75.5
ADD COLUMN "ai_fitment_result" VARCHAR(50), -- For "Best Fit", "Mid Fit", etc.
ADD COLUMN "ai_profile_score" REAL,
ADD COLUMN "ai_psychometric_score" REAL,
ADD COLUMN "ai_is_fresher" BOOLEAN;

-- Add columns for AI-evaluated personality scores (0-1 range from model)
ALTER TABLE public.resumes
ADD COLUMN "ai_Openness" REAL,
ADD COLUMN "ai_Conscientiousness" REAL,
ADD COLUMN "ai_Extraversion" REAL,
ADD COLUMN "ai_Agreeableness" REAL,
ADD COLUMN "ai_Neuroticism" REAL;


COMMENT ON COLUMN public.resumes."Openness" IS 'User input personality trait: Openness score (0-100)';
COMMENT ON COLUMN public.resumes."Conscientiousness" IS 'User input personality trait: Conscientiousness score (0-100)';
COMMENT ON COLUMN public.resumes."Extraversion" IS 'User input personality trait: Extraversion score (0-100)';
COMMENT ON COLUMN public.resumes."Agreeableness" IS 'User input personality trait: Agreeableness score (0-100)';
COMMENT ON COLUMN public.resumes."Neuroticism" IS 'User input personality trait: Neuroticism score (0-100)';

COMMENT ON COLUMN public.resumes."ai_final_score" IS 'Overall final score from AI model (0-100)';
COMMENT ON COLUMN public.resumes."ai_fitment_result" IS 'Fitment category from AI model (e.g., Best Fit)';
COMMENT ON COLUMN public.resumes."ai_profile_score" IS 'Profile score component from AI model (0-100)';
COMMENT ON COLUMN public.resumes."ai_psychometric_score" IS 'Psychometric score component from AI model (0-100)';
COMMENT ON COLUMN public.resumes."ai_is_fresher" IS 'Boolean indicating if AI model classified as fresher';

COMMENT ON COLUMN public.resumes."ai_Openness" IS 'AI model output for Openness (0-1 range)';
COMMENT ON COLUMN public.resumes."ai_Conscientiousness" IS 'AI model output for Conscientiousness (0-1 range)';
COMMENT ON COLUMN public.resumes."ai_Extraversion" IS 'AI model output for Extraversion (0-1 range)';
COMMENT ON COLUMN public.resumes."ai_Agreeableness" IS 'AI model output for Agreeableness (0-1 range)';
COMMENT ON COLUMN public.resumes."ai_Neuroticism" IS 'AI model output for Neuroticism (0-1 range)';
