import { ResumeData } from "@/types/resume";
import axios, { AxiosError } from 'axios';

// Configure axios defaults
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000/api',
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
  withCredentials: true,
});

// New axios instance for the Python model API
const modelApi = axios.create({
    baseURL: 'http://127.0.0.1:8000', // Changed port from 8000 to 8001
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    },
});

// Add a request interceptor to handle form data
api.interceptors.request.use(
  (config) => {
    // If the data is FormData, remove the Content-Type header
    // to let the browser set it with the correct boundary
    if (config.data instanceof FormData) {
      if (config.headers) {
        delete config.headers['Content-Type'];
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add a response interceptor to handle errors consistently
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError<{ message?: string }>) => {
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      const errorMessage = error.response.data?.message || 'An error occurred';
      return Promise.reject(new Error(errorMessage));
    } else if (error.request) {
      // The request was made but no response was received
      return Promise.reject(new Error('No response from server. Please check your connection.'));
    } else {
      // Something happened in setting up the request that triggered an Error
      return Promise.reject(error);
    }
  }
);

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

// --- New Types for AI Model Evaluation ---
interface AiModelInput {
    pg_institute: string; 
    phd_institute: number; 
    longevity_years: number;
    achievements_count: number;
    trainings_count: number;
    workshops_count: number;
    research_papers_count: number;
    patents_count: number;
    books_count: number;
    is_jk: number; 
    Openness?: number; // Expected by Python model (0-1 range)
    Conscientiousness?: number; // Expected by Python model (0-1 range)
    Extraversion?: number; // Expected by Python model (0-1 range)
    Agreeableness?: number; // Expected by Python model (0-1 range)
    Neuroticism?: number; // Expected by Python model (0-1 range)
}

interface AiModelResponse {
    profile_score: number;
    psychometric_score: number;
    final_score: number;
    fitment_result: "Best Fit" | "Mid Fit" | "Worst Fit";
    is_fresher: boolean;
    Openness?: number;
    Conscientiousness?: number;
    Extraversion?: number;
    Agreeableness?: number;
    Neuroticism?: number;
}
// --- End of New Types ---

export const saveResume = async (
  resumeData: ResumeData, 
  file?: File
): Promise<ApiResponse<{
  id: string;
  file_url?: string;
  file_path?: string;
  original_filename?: string;
  file_size?: number;
  mime_type?: string;
}>> => {
  const formData = new FormData();
  
  try {
    // Add resume data as JSON
    formData.append('data', JSON.stringify(resumeData));
    
    // If there's a file, add it to the form data with field name 'file' to match the server's multer configuration
    if (file) {
      formData.append('file', file);
    }
    
    // Make the request with form data
    // The interceptor will handle the Content-Type header for FormData
    const response = await api.post('/resumes', formData, {
      headers: {
        // The interceptor will handle the Content-Type header
      },
      // Required for Node.js 18+ when sending a body with certain content types
      // @ts-ignore - The type definition might not include this option yet
      duplex: 'half'
    });
    
    return { 
      success: true, 
      data: response.data 
    };
  } catch (error) {
    console.error('Error saving resume:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    return { 
      success: false, 
      error: errorMessage 
    };
  }
};

export const getResume = async (id: string): Promise<ApiResponse<ResumeData>> => {
  try {
    const response = await api.get(`/resumes/${id}`);
    return { 
      success: true, 
      data: response.data 
    };
  } catch (error) {
    console.error('Error fetching resume:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    return { 
      success: false, 
      error: errorMessage 
    };
  }
};

interface SearchResult {
  id: string;
  name: string;
  email: string;
  best_fit_for: string;
  // Add other fields as needed
}

export const searchResumes = async (query: string): Promise<ApiResponse<SearchResult[]>> => {
  try {
    const response = await api.get('/resumes/search', {
      params: { query }
    });
    
    return { 
      success: true, 
      data: response.data 
    };
  } catch (error) {
    console.error('Error searching resumes:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    return { 
      success: false, 
      error: errorMessage 
    };
  }
};

// --- New Function to Update Resume ---
export const updateResume = async (
  resumeId: string, 
  resumeData: ResumeData, 
  file?: File // Optional: if you allow file re-upload during update
): Promise<ApiResponse<{ id: string; /* other fields expected from update */ }>> => {
  let payload: FormData | ResumeData;
  const headers: { [key: string]: string } = {};

  if (file) {
    const formData = new FormData();
    formData.append('data', JSON.stringify(resumeData));
    formData.append('file', file);
    payload = formData;
    // The interceptor will handle Content-Type for FormData
  } else {
    payload = resumeData;
    // Axios default Content-Type is application/json for objects
  }

  try {
    const response = await api.put(`/resumes/${resumeId}`, payload, {
        headers: headers,
        // @ts-ignore
        duplex: file ? 'half' : undefined // duplex: 'half' typically for FormData with Node.js 18+
    });
    return {
      success: true,
      data: response.data,
    };
  } catch (error) {
    console.error('Error updating resume:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred while updating resume';
    if (axios.isAxiosError(error) && error.response) {
      return {
        success: false,
        error: error.response.data?.detail || error.response.data?.message || errorMessage,
      };
    }
    return {
      success: false,
      error: errorMessage,
    };
  }
};
// --- End of New Function ---

// --- New Function to call the Python AI Model ---
export const evaluateResumeWithAI = async (resumeData: ResumeData): Promise<ApiResponse<AiModelResponse>> => {
  try {
    const modelInput: AiModelInput = {
      pg_institute: resumeData.pg_institute || "",
      phd_institute: resumeData.phd_institute,
      longevity_years: resumeData.longevity_years,
      achievements_count: resumeData.achievements_count,
      trainings_count: resumeData.trainings_count,
      workshops_count: resumeData.workshops_count,
      research_papers_count: resumeData.research_papers_count,
      patents_count: resumeData.patents_count,
      books_count: resumeData.books_count,
      is_jk: resumeData.is_jk,
      // Convert form scores (0-100) to model scores (0-1)
      Openness: resumeData.Openness !== undefined ? resumeData.Openness / 100 : 0, 
      Conscientiousness: resumeData.Conscientiousness !== undefined ? resumeData.Conscientiousness / 100 : 0,
      Extraversion: resumeData.Extraversion !== undefined ? resumeData.Extraversion / 100 : 0,
      Agreeableness: resumeData.Agreeableness !== undefined ? resumeData.Agreeableness / 100 : 0,
      Neuroticism: resumeData.Neuroticism !== undefined ? resumeData.Neuroticism / 100 : 0,
    };

    const response = await modelApi.post<AiModelResponse>("/evaluate", modelInput);
    return {
      success: true,
      data: response.data,
    };
  } catch (error) {
    console.error('Error evaluating resume with AI model:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred while evaluating with AI model';
     if (axios.isAxiosError(error) && error.response) {
      return {
        success: false,
        error: error.response.data?.detail || errorMessage,
      };
    }
    return {
      success: false,
      error: errorMessage,
    };
  }
};
// --- End of New Function ---
