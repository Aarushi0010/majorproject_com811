export interface ResumeData {
  personalInfo: {
    name: string;
    email: string;
    phone: string;
    address?: string;
    summary?: string;
  };
  education: Education[];
  experience: Experience[];
  skills: string[];
  ug_institute?: string;
  pg_institute?: string;
  phd_institute: number; // 0 for no, 1 for yes
  longevity_years: number; // working years count
  number_of_jobs: number;
  average_experience: number; // longevity/number of jobs
  skills_count: number;
  achievements_count: number;
  achievements: string[];
  trainings_count: number;
  trainings: string[];
  workshops_count: number;
  workshops: string[];
  research_papers: string[];
  research_papers_count: number;
  patents: string[];
  patents_count: number;
  books: string[];
  books_count: number;
  is_jk: number; // 0 for no, 1 for yes (J&K)
  projects_count: number;
  projects: string[];
  best_fit_for?: string; // Making this optional and adding it to the interface

  // User Input Personality Traits (scores 0-100 from form)
  Openness?: number;
  Conscientiousness?: number;
  Extraversion?: number;
  Agreeableness?: number;
  Neuroticism?: number;

  // Fields to store AI evaluation results
  id?: string; // Resume ID from the database
  ai_final_score?: number;
  ai_fitment_result?: "Best Fit" | "Mid Fit" | "Worst Fit";
  ai_profile_score?: number;
  ai_psychometric_score?: number;
  ai_is_fresher?: boolean;
  // Store AI-evaluated personality scores (model output, typically 0-1 range)
  ai_Openness?: number;
  ai_Conscientiousness?: number;
  ai_Extraversion?: number;
  ai_Agreeableness?: number;
  ai_Neuroticism?: number;
}

export interface Education {
  institution: string;
  degree: string;
  field?: string;
  startDate?: string;
  endDate?: string;
  gpa?: string;
}

export interface Experience {
  company: string;
  position: string;
  startDate?: string;
  endDate?: string;
  description?: string;
  location?: string;
}
