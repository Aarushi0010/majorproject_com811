import pandas as pd
import joblib
import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

# Load model and weights
MODEL_PATH = "allnewmodel.pkl"

# FastAPI instance
app = FastAPI()

# CORS Middleware
# origins = [
#     "http://localhost:5173", # Assuming your React app runs on this port
#     "http://127.0.0.1:5173",
#     # Add any other origins if necessary
# ]

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Changed to allow all origins for debugging
    allow_credentials=True,
    allow_methods=["*"], # Allows all methods
    allow_headers=["*"], # Allows all headers
)

# Define input schema
class ResumeData(BaseModel):
    pg_institute: str
    phd_institute: int
    longevity_years: float
    achievements_count: float
    trainings_count: float
    workshops_count: float
    research_papers_count: float
    patents_count: float
    books_count: float
    is_jk: int
    Openness: float = 0
    Conscientiousness: float = 0
    Extraversion: float = 0
    Agreeableness: float = 0
    Neuroticism: float = 0

# Evaluation function
def evaluate_candidate(input_data: ResumeData):
    model = joblib.load(MODEL_PATH)
    is_fresher = input_data.longevity_years < 2

    # Default personality scores if input is 0 (on a 0-1 scale)
    # These are used if the frontend sends 0, implying user did not input them
    default_scores = {
        "Openness": 0.6,
        "Conscientiousness": 0.7,
        "Extraversion": 0.5,
        "Agreeableness": 0.6,
        "Neuroticism": 0.3 
    }

    processed_personality = {}
    for trait in ["Openness", "Conscientiousness", "Extraversion", "Agreeableness", "Neuroticism"]:
        input_value = getattr(input_data, trait)
        if input_value is not None and abs(input_value) < 0.01: # Check if value is effectively zero
            processed_personality[trait] = default_scores[trait]
        elif input_value is not None:
            processed_personality[trait] = input_value
        else: # Should not happen if Pydantic default is 0
            processed_personality[trait] = default_scores[trait] # Fallback just in case
    
    # print("Processed personality scores (after defaults for zeros): ", processed_personality)

    # Convert pg_institute string to a numerical value for calculation
    # Assuming 'Tier 1' or 'Tier 2' are positive indicators, others are not.
    pg_institute_numeric = 1 if input_data.pg_institute in ["Tier 1", "Tier 2"] else 0

    # Normalize input features
    features = {
        'pg_institute': pg_institute_numeric, # Use the converted numeric value
        'phd_institute': input_data.phd_institute,
        'achievements_count': min(input_data.achievements_count / 10, 1),
        'trainings_count': min(input_data.trainings_count / 5, 1) if is_fresher else min(input_data.trainings_count / 10, 1),
        'workshops_count': min(input_data.workshops_count / 5, 1) if is_fresher else min(input_data.workshops_count / 10, 1),
        'research_papers_count': min(input_data.research_papers_count / 5, 1) if is_fresher else min(input_data.research_papers_count / 10, 1),
        'patents_count': min(input_data.patents_count / 2, 1) if is_fresher else min(input_data.patents_count / 5, 1),
        'books_count': min(input_data.books_count / 5, 1),
        'is_jk': input_data.is_jk,
        'longevity_years': min(input_data.longevity_years / 5, 1)
    }

    # Set weights
    if is_fresher:
        weights = {
            'pg_institute': 0.1, 'phd_institute': 0.2, 'achievements_count': 0.1, 'trainings_count': 0.1,
            'workshops_count': 0.1, 'research_papers_count': 0.1, 'patents_count': 0.1, 'books_count': 0.1, 'is_jk': 0.1
        }
        profile_weight = 0.5
        personality_weight = 0.5
    else:
        weights = {
            'pg_institute': 0.1, 'phd_institute': 0.2, 'longevity_years': 0.1, 'achievements_count': 0.05,
            'trainings_count': 0.05, 'workshops_count': 0.05, 'research_papers_count': 0.2, 'patents_count': 0.1,
            'books_count': 0.05, 'is_jk': 0.1
        }
        profile_weight = 0.7
        personality_weight = 0.3

    # Calculate scores
    profile_score = sum(features[k] * weights[k] for k in weights)
    psychometric_score = sum([
        processed_personality["Openness"] * 0.2,
        processed_personality["Conscientiousness"] * 0.2,
        processed_personality["Extraversion"] * 0.2,
        processed_personality["Agreeableness"] * 0.2,
        processed_personality["Neuroticism"] * 0.2
    ])

    final_score = (profile_score * profile_weight + psychometric_score * personality_weight) * 100

    fit = "Best Fit" if final_score >= 75 else "Mid Fit" if final_score >= 50 else "Worst Fit"

    return {
        "profile_score": round(profile_score * 100, 2),
        "psychometric_score": round(psychometric_score * 100, 2),
        "final_score": round(final_score, 2),
        "fitment_result": fit,
        "is_fresher": is_fresher,
        "Openness": processed_personality["Openness"],
        "Conscientiousness": processed_personality["Conscientiousness"],
        "Extraversion": processed_personality["Extraversion"],
        "Agreeableness": processed_personality["Agreeableness"],
        "Neuroticism": processed_personality["Neuroticism"]
    }

# API route
@app.post("/evaluate")
def evaluate(resume: ResumeData):
    try:
        return evaluate_candidate(resume)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
