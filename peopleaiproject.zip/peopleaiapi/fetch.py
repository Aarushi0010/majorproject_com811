from flask import Flask, request, jsonify
import pandas as pd
import joblib
from supabase import create_client, Client
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Load model
model = joblib.load(open('./allnewmodel.pkl', 'rb'))

# Supabase configuration
SUPABASE_URL = "https://fjydxbqbmpjkosvykrpi.supabase.co"
SUPABASE_KEY = "your_supabase_key_here"
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# Load psychometric scores from a separate table (or input)
def fetch_psychometric(auth_id):
    try:
        response = supabase.table('psychometrics').select('*').eq('auth_id', auth_id).execute()
        if not response.data:
            return None
        return response.data[0]
    except Exception as e:
        print("Error fetching psychometric data:", e)
        return None

@app.route('/calculate_score', methods=['POST'])
def calculate_score():
    auth_id = request.json.get('auth_id')
    if not auth_id:
        return jsonify({"error": "auth_id is required"}), 400

    try:
        profile_response = supabase.table('profile').select('*').eq('auth_id', auth_id).execute()
        if not profile_response.data:
            return jsonify({"error": "No data found for the provided auth_id"}), 404

        profile = profile_response.data[0]
        psychometric = fetch_psychometric(auth_id)

        # Determine if fresher or experienced
        longevity_years = float(profile.get('longevity', 0))
        is_fresher = longevity_years < 2

        # Normalize profile data
        profile_features = {
            'pg_institute': 1 if profile.get('is_pg') == 'true' else 0,
            'phd_institute': 1 if profile.get('is_phd') == 'true' else 0,
            'achievements_count': min(float(profile.get('achievements', 0)) / 10, 1),
            'trainings_count': min(float(profile.get('trainings', 0)) / 5, 1) if is_fresher else min(float(profile.get('trainings', 0)) / 10, 1),
            'workshops_count': min(float(profile.get('workshops', 0)) / 5, 1) if is_fresher else min(float(profile.get('workshops', 0)) / 10, 1),
            'research_papers_count': min(float(profile.get('total_papers', 0)) / 5, 1) if is_fresher else min(float(profile.get('total_papers', 0)) / 10, 1),
            'patents_count': min(float(profile.get('total_patents', 0)) / 2, 1) if is_fresher else min(float(profile.get('total_patents', 0)) / 5, 1),
            'books_count': min(float(profile.get('books', 0)) / 5, 1),
            'is_jk': 1 if profile.get('from_jk') == 'true' else 0,
            'longevity_years': min(longevity_years / 5, 1)
        }

        # Define weights
        if is_fresher:
            weights = {
                'pg_institute': 0.1, 'phd_institute': 0.2, 'achievements_count': 0.1, 'trainings_count': 0.1,
                'workshops_count': 0.1, 'research_papers_count': 0.1, 'patents_count': 0.1, 'books_count': 0.1,
                'is_jk': 0.1
            }
            profile_weight = 0.5
            personality_weight = 0.5
        else:
            weights = {
                'pg_institute': 0.1, 'phd_institute': 0.2, 'longevity_years': 0.1, 'achievements_count': 0.05,
                'trainings_count': 0.05, 'workshops_count': 0.05, 'research_papers_count': 0.2,
                'patents_count': 0.1, 'books_count': 0.05, 'is_jk': 0.1
            }
            profile_weight = 0.7
            personality_weight = 0.3

        # Calculate profile score
        profile_score = sum(profile_features[k] * weights[k] for k in weights)

        # Calculate psychometric score
        if psychometric:
            personality_traits = ['Openness', 'Conscientiousness', 'Extraversion', 'Agreeableness', 'Neuroticism']
            psychometric_score = sum(float(psychometric.get(trait, 0)) * 0.2 for trait in personality_traits)
        else:
            psychometric_score = 0

        final_score = (profile_score * profile_weight + psychometric_score * personality_weight) * 100

        result = {
            "auth_id": auth_id,
            "is_fresher": is_fresher,
            "profile_score": round(profile_score * 100, 2),
            "psychometric_score": round(psychometric_score * 100, 2),
            "final_score": round(final_score, 2),
            "fitment_result": "Best Fit" if final_score >= 75 else "Mid Fit" if final_score >= 50 else "Worst Fit"
        }

        return jsonify(result), 200

    except Exception as e:
        return jsonify({"error": "Failed to calculate score", "details": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5500)
